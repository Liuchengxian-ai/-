import numpy as np
import matplotlib.pyplot as plt

# 一个完整周期
T = 2000 * np.pi

# 采样点：一个周期约 6283，采样 200000 点保证曲线平滑
x = np.linspace(0, T, 200000)

y = np.sin(0.2 * x) + np.sin(0.311 * x) + np.sin(0.42 * x)

plt.figure(figsize=(16, 5))
plt.plot(x, y, linewidth=0.3)

plt.title(r'One period of $y=\sin(0.2x)+\sin(0.311x)+\sin(0.42x)$')
plt.xlabel('x')
plt.ylabel('y')
plt.xlim(0, T)
plt.grid(True, alpha=0.3)
plt.tight_layout()

plt.savefig('one_period_plot.png', dpi=300)
plt.show()