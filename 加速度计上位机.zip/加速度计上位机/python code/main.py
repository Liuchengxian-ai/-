import serial

ser = serial.Serial("COM5",115200,timeout=1)
ser.write(b'HELLO')
data=ser.read(5)
print(data)
ser.close()
#
# ser = serial.Serial("COM5",115200,timeout=1)
#
#
# for i in range(20):
#     data = ser.readline()
#     text=data.decode('utf-8', errors="replace").strip()
#     if not text.startswith("X："):
#         continue
#     text = text.split(",")
#     if len(text) != 3:
#         continue
#     if not text[1].startswith("Y") or not text[2].startswith("Z"):
#         continue
#     try:
#         x = float(text[0].split(":")[1])
#         y = float(text[1].split(":")[1])
#         z = float(text[2].split(":")[1])
#     except(ValueError, IndexError):
#         continue
#
#
#     print(x,y,z)
#
# ser.close()


# text = "X:1.80,Y:1.7,Z:1.9"
# data=text.split(",")
# x = float(data[0].split(":")[1])
# y = float(data[1].split(":")[1])
# z = float(data[2].split(":")[1])
# print(x)
# print(y)
# print(z)


#回环测试(自收自发)
# ser = serial.Serial("COM5",115200,timeout=1)
# ser.write(b"\n")
# data= ser.readline()
# print("接收到：",data)
# ser.close()

#测试串口是否打开正常
# ser = serial.Serial("COM5",115200,timeout = 1)
# print("串口是否打开",ser.is_open)
# ser.close()
# print("串口是否打开",ser.is_open)


#读取电脑串口情况
# from serial.tools import list_ports
#
# ports = list_ports.comports() #从电脑取出端口到ports里
#
# for port in ports:#遍历所有的ports
#     print(port.device, port.description)#把ports的设备和描述打印出来
